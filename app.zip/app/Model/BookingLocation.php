<?php

class BookingLocation extends AppModel {

    public $name = 'BookingLocation';
    public $validate = array();

}
?>