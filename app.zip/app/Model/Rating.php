<?php

class Rating extends AppModel {

    public $name = 'Rating';
    public $validate = array();

}
?>