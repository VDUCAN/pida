<?php

class BankDetail extends AppModel {

    public $name = 'BankDetail';
    public $validate = array();

}
?>