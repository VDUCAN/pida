<?php
class EmailConfig {
    public $sendgrid = array(
        'host' => 'mail.pida.com',
        'port' => 26,
        'username' => 'admin@pida.com',
        'password' => 'c0]GZ9!jg;81',
        'transport' => 'Smtp'
    );
}
?>