<?php

class Transaction extends AppModel {

    public $name = 'Transaction';
    public $validate = array();
    
}