<?php
class EmailConfig {
    public $sendgrid = array(
        'host' => 'smtp.sendgrid.net',
        'port' => 587,
        'username' => 'Pidaapp',
        'password' => 'pidaappgo2Y7nLZ',
        'transport' => 'Smtp'
    );
}
?>