<?php

class Booking extends AppModel {

    public $name = 'Booking';
    public $validate = array();

}
?>